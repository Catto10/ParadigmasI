public class HolaMundo {
    public static void main(String[] args) {
        System.out.println("Hola MUndo Clash clash");
    }
}
